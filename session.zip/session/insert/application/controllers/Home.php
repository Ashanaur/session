<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
        $data['title'] = 'insert page';
        $this->load->view('inc/header',$data);
        $this->load->view('inc/nav');
        $this->load->view('form');
        $this->load->view('inc/footer');
    }
    public function test()
    {
        $data['title'] = 'Test page';
        $this->load->view('inc/header',$data);
        $this->load->view('inc/nav');
        $this->load->view('form1');
        $this->load->view('inc/footer');   
    }
    public function view_verify1(){
        $data['title'] = 'View Test page';
        $this->load->model('insert_model');
        $data['post'] = $this->insert_model->getdata();
        $this->load->view('inc/header',$data);
        $this->load->view('inc/nav');
        $this->load->view('View_test');
        $this->load->view('inc/footer'); 
    }
    public function upinsert(){
        $id = $this->input->post('id');

        $this->form_validation->set_rules('name','Your Name', 'required');
        $this->form_validation->set_rules('user','Your UserName', 'required');
        $this->form_validation->set_rules('email','Your Email', 'required');
        $this->form_validation->set_rules('pw', 'Your password', 'required');
        $this->form_validation->set_rules('pw1', 'Confirm Password', 'required|matches[pw]');

        if($this->form_validation->run()){
            $data['name'] = $this->input->post('name');
            $data['user'] = $this->input->post('user');
            $data['email'] = $this->input->post('email');
            $data['pw'] = $this->input->post('pw');
            $data['pw1'] = $this->input->post('pw1');
            $this->load->model('insert_model');
            $status = $this->insert_model->upinsert($id,$data);
            if($status == true){
                redirect('home/update/updated');
            }else{
                $this->update();
            }
        }else{
            echo "form validation failed";
        }
    }
    public function verify1()
    {
        $this->form_validation->set_rules('name', 'Your Name', 'required');
        $this->form_validation->set_rules('user', 'Your UserName', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('pw', 'Your password', 'required');
        $this->form_validation->set_rules('pw1', 'Confirm Password', 'required|matches[pw]');
        
        if($this->form_validation->run()){
            $data['name'] = $this->input->post('name');
            $data['user'] = $this->input->post('user');
            $data['email'] = $this->input->post('email');
            $data['pw'] = $this->input->post('pw');
            $data['pw1'] = $this->input->post('pw1');
            $this->load->model('insert_model');
            $status = $this->insert_model->inserttest($data);
            if($status > 0){
                echo 'inserted successfully';
            }
        }else{
            $this->test();
        }
    }
    public function verify()
    {
        $this->form_validation->set_rules('name', 'Your name', 'required');
        $this->form_validation->set_rules('email', 'Your email', 'required');
        $this->form_validation->set_rules('phone', 'Your phone', 'required');
        $this->form_validation->set_rules('age', 'Your Age', 'required');
        $this->form_validation->set_rules('address', 'Your Address', 'required');
        if($this->form_validation->run()){
            $data['name'] = $this->input->post('name');
            $data['email'] = $this->input->post('email');
            $data['phone'] = $this->input->post('phone');
            $data['age'] = $this->input->post('age');
            $data['address'] = $this->input->post('address');
            $this->load->model('insert_model');
            $status=$this->insert_model->insertinfor($data);
			if($status>0){
				echo "insert Successful";
			} 
        }else{
            $this->index();
        }
    }
    public function delete()
    {
        $id = $this->uri->segment(3);
        $this->load->model('insert_model');
        if($this->insert_model->delete($id)){
            redirect('home/view_verify1/deleted');
        }
    }
    public function update()
    {
        $id = $this->uri->segment(3);
        $this->load->model('insert_model');
        $data['title'] = 'Update';
        $data['single'] = $this->insert_model->single($id);
        if(isset($data['single'])){
            $this->load->view('inc/header',$data);
            $this->load->view('inc/nav');
            $this->load->view('upform',$data);
            $this->load->view('inc/footer'); 
        }
    }

}
