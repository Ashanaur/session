<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
        $data['title'] = "Login Page";
        $this->load->view('inc/header',$data);
        $this->load->view('inc/nav',$data);
        $this->load->view('login');
        $this->load->view('inc/footer');
    }
    public function dashboard()
    {
        if($this->session->userdata('user')!=''){
            echo 'welcome '.$this->session->userdata('user').'<br />';
            ?>
                <a href="<?php echo base_url();?>login/logout">Logout</a>
            <?php
        }
    }
    public function logout()
    {
        $this->session->user_userdata('user');
        redirect(base_url().'login/index');
    }
    
    public function validation()
    {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Your Email', 'required|vaild_email');
        $this->form_validation->set_rules('password', 'Your Password', 'required');

        if($this->form_validation->run()){
            $email = $this->input->post('email');
            $pass = md5($this->input->post('password'));
            $this->load->model('insert_model');
            if($this->insert_model->logincheck($email,$pass)){
                $data = array('user'=>$email);
                $this->session->set_userdata($data);
                redirect(base_url().'login/dashboard');
            }else{
                $this->session->set_flashdata('apple','login failed');
                redirect(base_url().'login/index');
            }


        }else{
            redirect(base_url().'login/index');
        }
    }
}