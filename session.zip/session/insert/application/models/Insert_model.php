<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insert_model extends CI_Model {
    public function insertinfor($data)
    {
        $this->db->insert("reg",$data);
        return $this->db->insert_id();
    }
    public function inserttest($data)
    {
        $this->db->insert("test",$data);
        return $this->db->insert_id();
    }
    public function getdata()
    {
        $query = $this->db->get('test');
        return $query->result();
    }
    public function delete($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('test');
        return true;
    }
    public function single($id)
    {
        $this->db->where('id',$id);
        $query = $this->db->get('test');
        return $query->result();
    }
    public function upinsert($id,$data)
    {
        $this->db->where('id', $id);
        $this->db->update('test', $data);
        return true;
    }
    public function logincheck($email,$password)
    {
        $this->db->where('email',$email);
        $this->db->where('pw1',$password);
        $query = $this->db->get('test');
        if($query->num_rows>0){
            return true;
        }else{
            return false;
        }
    }

}