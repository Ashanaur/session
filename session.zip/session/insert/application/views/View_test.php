
<div>
    <h2 class="text-center bg-danger text-warning">Information</h2>
</div>
<table class="table table-striped table-dark">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">User</th>
            <th scope="col">Email</th>
            <th scope="col">Password</th>
            <th scope="col">Delete</th>
            <th scope="col">Update</th>
        </tr>
        <?php
$del = $this->uri->segment(3);
if($del == 'deleted'){
?>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <strong>Delete Successfully.</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php
}
?>
    </thead>
    <tbody>
    <?php
        foreach($post as $value){
            ?>
            <tr>
                <th scope="row"><?php echo $value->id;?></th>
                <td><?php echo $value->name;?></td>
                <td><?php echo $value->user;?></td>
                <td><?php echo $value->email;?></td>
                <td><?php echo $value->pw1;?></td>
                <td><a href="<?php echo base_url()."home/delete/".$value->id;?>" class="btn btn-danger">Delete</a></td>
                <td><a href="<?php echo base_url()."home/update/".$value->id;?>" class="btn btn-success">Update</a></td>         
            </tr>
            <?php
        }
    ?>
    </tbody>
</table>
        