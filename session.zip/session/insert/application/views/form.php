<div class="container">
    <h1 class="text-center">Information</h1>
    <form action="<?php echo base_url();?>home/verify" method='post'>
        <label for="name">Name</label>
        <input type="text" id="name" name="name" class='form-control mt-3'>
        <span class="text-danger"><?php echo form_error('name')?></span>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" class='form-control mt-3'>
        <span class="text-danger"><?php echo form_error('email')?></span>
        <label for="phone">Phone</label>
        <input type="number" id='phone' name="phone" class='form-control mt-3'>
        <span class="text-danger"><?php echo form_error('phone')?></span>
        <label for="age">Age</label>
        <input type="number" id='age' name="age" class='form-control mt-3'>
        <span class="text-danger"><?php echo form_error('age')?></span>
        <label for="add">Address</label>
        <textarea name="address" id="add" class="form-control" cols="30" rows="10"></textarea>
        <span class="text-danger"><?php echo form_error('address')?></span>
        <button type="submit" name="submit" class="btn btn-success mt-3 mb-3">Submit</button>
        <button type="reset" class="btn btn-danger mt-3 mb-3">Clear</button>
    </form>
</div>