<footer>
			<div class="pt-5 pb-5" style="background-color:#1c1c3f;"><!--  footer start -->
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-sm-12">
							<h4 class="text-center text-white f">&copy;Copyrights 2018. All rights reserved by: ashanur.xyz</h4>
						</div>
					</div>
				</div>
			</div>
		</footer>
        <script src="<?php echo base_url();?>asset/js/jquery-3.3.1.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>asset/js/bootstrap.bundle.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url();?>asset/js/alert.js" type="text/javascript"></script>
    </body>
</html>