

<div class='alert alert-danger'>
    <?php echo $this->session->flashdata('apple');?>
</div>

<div class="container">
<h1 class='text-center'>Login Here</h1>
    <form action="<?php echo base_url();?>login/validation" method="post">
        <input type="email" class="form-control mt-2" name="email" placeholder="Enter Email.">
        <span class="text-danger"><?php echo form_error('email')?></span>
        <input type="password" class="form-control mt-2" name="password" placeholder="Enter Email.">
        <span class="text-danger"><?php echo form_error('password')?></span>
        <button type="submit" name="submit" class="btn btn-success mt-2 mb-5">Submit</button>
        <button type="reset" class="btn btn-danger mt-2 mb-5">Submit</button>
    </form>
</div>