<?php 
    $del = $this->uri->segment(3);
    if($del == 'updated'){
        ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Updated Successfully.</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php
    }
?>


<?php 
    foreach($single as $data){
?>
<div class="container">
    <h1 class='text-center mt-4'>Test Information</h1>
    <form action="<?php echo base_url()?>home/upinsert" method="post">
        <input type="text"  class='form-control mt-3' name='name' value="<?php echo $data->name;?>" placeholder='Enter Name..'>
        <span class="text-danger"><?php echo form_error('name')?></span>
        <input type="text"  class='form-control mt-4' name='user' value="<?php echo $data->user;?>" placeholder='Enter UserName..'>
        <span class="text-danger"><?php echo form_error('user')?></span>
        <input type="email"  class='form-control mt-4' name='email' value="<?php echo $data->email;?>" placeholder='Enter Email..'>
        <span class="text-danger"><?php echo form_error('email')?></span>
        <input type="password"  class='form-control mt-4' name='pw' value="<?php echo $data->pw;?>" placeholder='Enter Password..'>
        <span class="text-danger"><?php echo form_error('pw')?></span>
        <input type="password"  class='form-control mt-4' name='pw1' value="<?php echo $data->pw1;?>" placeholder='Confirm Password..'>
        <span class="text-danger"><?php echo form_error('pw1')?></span>
        <input type="hidden" name="id" value="<?php echo $data->id;?>">
        <button type="submit" class='btn btn-success mt-4 mb-5'>Submit</button>
        <button type="reset" class='btn btn-danger mt-4 mb-5'>Clear</button>
    </form>
</div>

    <?php
    }
?>

